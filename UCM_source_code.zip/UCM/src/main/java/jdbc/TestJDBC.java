package jdbc;

import java.util.List;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class TestJDBC extends JdbcDaoSupport {

	public Test getAdmin(int id) {
		String SQL = "select * from test where Id_P = ?";
		try {
			Test test = this.getJdbcTemplate().queryForObject(SQL,
					new Object[] { id }, new TestMapper());
			return test;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<Test> findAllTests() {  
		String SQL = "select * from test";

			List<Test> tests = this.getJdbcTemplate().query(SQL, new Object[]{}, new TestMapper());
			
        return tests;  
    }  
       
    public Test findById(long id) {  
    	String SQL = "select * from test where Id_P = ?";
		try {
			Test test = this.getJdbcTemplate().queryForObject(SQL,
					new Object[] { id }, new TestMapper());
			return test;
		} catch (EmptyResultDataAccessException e) {
			return null;
		} 
    }      
       
    public void saveTest(Test test) {  
    	try {
			String SQL = "insert into test (Id_P, LastName, firstName, Address, City) values (?, ?, ?, ?, ?)";
			this.getJdbcTemplate().update(SQL, test.getIdP(), test.getLastName(), test.getFirstName(), test.getAddress(), test.getCity());
		} catch (DuplicateKeyException e) {
			System.out.println("create error");
			throw e;
		}  
    }  
   
    public void updateTest(long id, String firstName) {  
    	String SQL = "update test set FirstName = ? where Id_P = ?";
		this.getJdbcTemplate().update(SQL, firstName, id);
    }  
   
    public void deleteTestById(long id) {  
    	String SQL = "delete from test where Id_P = ?";
		this.getJdbcTemplate().update(SQL, id);
    }  
    
    /** 
     * 根据表名称创建一张表 
     * @param tableName 
     */  
    public void createTable(String tableName){  
        StringBuffer sb = new StringBuffer("");  
        sb.append("CREATE TABLE `" + tableName + "` (");  
        sb.append(" `id` int(11) NOT NULL AUTO_INCREMENT,");             
        sb.append(" `tableName` varchar(255) DEFAULT '',");  
        sb.append(" PRIMARY KEY (`id`)");  
        sb.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8;");  
        try {  
        	this.getJdbcTemplate().update(sb.toString());  
        } catch (Exception e) {  
            e.printStackTrace();  
        }    
    }  
   
//    public boolean isTestExist(Test Test) {  
//        return findByName(Test.getName())!=null;  
//    }  
//   
//    private static List<Test> populateDummyTests(){  
//        List<Test> Tests = new ArrayList<Test>();  
//        Tests.add(new Test(counter.incrementAndGet(),"Sam",30, 70000));  
//        Tests.add(new Test(counter.incrementAndGet(),"Tom",40, 50000));  
//        Tests.add(new Test(counter.incrementAndGet(),"Jerome",45, 30000));  
//        Tests.add(new Test(counter.incrementAndGet(),"Silvia",50, 40000));  
//        return Tests;  
//    }  
//   
//    public void deleteAllTests() {  
//        Tests.clear();  
//    }  
}
