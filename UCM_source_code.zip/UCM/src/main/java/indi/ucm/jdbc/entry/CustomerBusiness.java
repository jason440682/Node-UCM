package indi.ucm.jdbc.entry;

// Info of customer business
public class CustomerBusiness {
    private long customerBusinessId;
    private long customerId;
    private String businessName;
    private int businessType;
    private int businessTimeZone;
    private String phoneNumber;
    private String businessFaxNumber;
    private String businessAddressStreet;
    private String businessAddressRoomNumber;
    private String businessAddressCity;
    private String businessAddressStateProvince;
    private int businessAddressCountry;
    private String businessDescription;

    /**
     * @return the customerBusinessId
     */
    public long getCustomerBusinessId() {
        return this.customerBusinessId;
    }

    /**
     * @param customerBusinessId
     *            the customerBusinessId to set
     */
    public void setCustomerBusinessId(final long customerBusinessId) {
        this.customerBusinessId = customerBusinessId;
    }

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the businessName
     */
    public String getBusinessName() {
        return this.businessName;
    }

    /**
     * @param businessName
     *            the businessName to set
     */
    public void setBusinessName(final String businessName) {
        this.businessName = businessName;
    }

    /**
     * @return the businessType
     */
    public int getBusinessType() {
        return this.businessType;
    }

    /**
     * @param businessType
     *            the businessType to set
     */
    public void setBusinessType(final int businessType) {
        this.businessType = businessType;
    }

    /**
     * @return the businessTimeZone
     */
    public int getBusinessTimeZone() {
        return this.businessTimeZone;
    }

    /**
     * @param businessTimeZone
     *            the businessTimeZone to set
     */
    public void setBusinessTimeZone(final int businessTimeZone) {
        this.businessTimeZone = businessTimeZone;
    }

    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    /**
     * @param phoneNumber
     *            the phoneNumber to set
     */
    public void setPhoneNumber(final String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the businessFaxNumber
     */
    public String getBusinessFaxNumber() {
        return this.businessFaxNumber;
    }

    /**
     * @param businessFaxNumber
     *            the businessFaxNumber to set
     */
    public void setBusinessFaxNumber(final String businessFaxNumber) {
        this.businessFaxNumber = businessFaxNumber;
    }

    /**
     * @return the businessAddressStreet
     */
    public String getBusinessAddressStreet() {
        return this.businessAddressStreet;
    }

    /**
     * @param businessAddressStreet
     *            the businessAddressStreet to set
     */
    public void setBusinessAddressStreet(final String businessAddressStreet) {
        this.businessAddressStreet = businessAddressStreet;
    }

    /**
     * @return the businessAddressRoomNumber
     */
    public String getBusinessAddressRoomNumber() {
        return this.businessAddressRoomNumber;
    }

    /**
     * @param businessAddressRoomNumber
     *            the businessAddressRoomNumber to set
     */
    public void setBusinessAddressRoomNumber(final String businessAddressRoomNumber) {
        this.businessAddressRoomNumber = businessAddressRoomNumber;
    }

    /**
     * @return the businessAddressCity
     */
    public String getBusinessAddressCity() {
        return this.businessAddressCity;
    }

    /**
     * @param businessAddressCity
     *            the businessAddressCity to set
     */
    public void setBusinessAddressCity(final String businessAddressCity) {
        this.businessAddressCity = businessAddressCity;
    }

    /**
     * @return the businessAddressStateProvince
     */
    public String getBusinessAddressStateProvince() {
        return this.businessAddressStateProvince;
    }

    /**
     * @param businessAddressStateProvince
     *            the businessAddressStateProvince to set
     */
    public void setBusinessAddressStateProvince(final String businessAddressStateProvince) {
        this.businessAddressStateProvince = businessAddressStateProvince;
    }

    /**
     * @return the businessAddressCountry
     */
    public int getBusinessAddressCountry() {
        return this.businessAddressCountry;
    }

    /**
     * @param businessAddressCountry
     *            the businessAddressCountry to set
     */
    public void setBusinessAddressCountry(final int businessAddressCountry) {
        this.businessAddressCountry = businessAddressCountry;
    }

    /**
     * @return the businessDescription
     */
    public String getBusinessDescription() {
        return this.businessDescription;
    }

    /**
     * @param businessDescription
     *            the businessDescription to set
     */
    public void setBusinessDescription(final String businessDescription) {
        this.businessDescription = businessDescription;
    }
}
