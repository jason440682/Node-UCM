package indi.ucm.jdbc.entry;

import java.sql.Timestamp;

// Info of customer payment
public class CustomerPayment {
    private long paymentId;
    private long customerWorkInvoiceId;
    private double paymentAmount;
    private int paymentMethod;
    private Timestamp paymentReceivedDateTime;
    private String userNote;

    /**
     * @return the paymentId
     */
    public long getPaymentId() {
        return this.paymentId;
    }

    /**
     * @param paymentId
     *            the paymentId to set
     */
    public void setPaymentId(final long paymentId) {
        this.paymentId = paymentId;
    }

    /**
     * @return the customerWorkInvoiceId
     */
    public long getCustomerWorkInvoiceId() {
        return this.customerWorkInvoiceId;
    }

    /**
     * @param customerWorkInvoiceId
     *            the customerWorkInvoiceId to set
     */
    public void setCustomerWorkInvoiceId(final long customerWorkInvoiceId) {
        this.customerWorkInvoiceId = customerWorkInvoiceId;
    }

    /**
     * @return the paymentAmount
     */
    public double getPaymentAmount() {
        return this.paymentAmount;
    }

    /**
     * @param paymentAmount
     *            the paymentAmount to set
     */
    public void setPaymentAmount(final double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    /**
     * @return the paymentMethod
     */
    public int getPaymentMethod() {
        return this.paymentMethod;
    }

    /**
     * @param paymentMethod
     *            the paymentMethod to set
     */
    public void setPaymentMethod(final int paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * @return the paymentReceivedDateTime
     */
    public Timestamp getPaymentReceivedDateTime() {
        return this.paymentReceivedDateTime;
    }

    /**
     * @param paymentReceivedDateTime
     *            the paymentReceivedDateTime to set
     */
    public void setPaymentReceivedDateTime(final Timestamp paymentReceivedDateTime) {
        this.paymentReceivedDateTime = paymentReceivedDateTime;
    }

    /**
     * @return the userNote
     */
    public String getUserNote() {
        return this.userNote;
    }

    /**
     * @param userNote
     *            the userNote to set
     */
    public void setUserNote(final String userNote) {
        this.userNote = userNote;
    }
}
