package indi.ucm.jdbc.entry;

//payment card info of master user
public class MasterUserPaymentCard {
	private long masterUserPaymentCardId;
	private long paymentCreditCardNumber;
	private String paymentCreditCardName;
	private int paymentCreditCardExpirationMonth;
	private int payemntCreditCardExpirationYear;
	private int paymentCreditCardCsvCode;
	private int paymentCreditCardZipCode;
	private String paymentCreditCardStatus;
	
	public long getMasterUserPaymentCardId() {
		return masterUserPaymentCardId;
	}
	public void setMasterUserPaymentCardId(long masterUserPaymentCardId) {
		this.masterUserPaymentCardId = masterUserPaymentCardId;
	}
	public long getPaymentCreditCardNumber() {
		return paymentCreditCardNumber;
	}
	public void setPaymentCreditCardNumber(long paymentCreditCardNumber) {
		this.paymentCreditCardNumber = paymentCreditCardNumber;
	}
	public String getPaymentCreditCardName() {
		return paymentCreditCardName;
	}
	public void setPaymentCreditCardName(String paymentCreditCardName) {
		this.paymentCreditCardName = paymentCreditCardName;
	}
	public int getPaymentCreditCardExpirationMonth() {
		return paymentCreditCardExpirationMonth;
	}
	public void setPaymentCreditCardExpirationMonth(
			int paymentCreditCardExpirationMonth) {
		this.paymentCreditCardExpirationMonth = paymentCreditCardExpirationMonth;
	}
	public int getPayemntCreditCardExpirationYear() {
		return payemntCreditCardExpirationYear;
	}
	public void setPayemntCreditCardExpirationYear(
			int payemntCreditCardExpirationYear) {
		this.payemntCreditCardExpirationYear = payemntCreditCardExpirationYear;
	}
	public int getPaymentCreditCardCsvCode() {
		return paymentCreditCardCsvCode;
	}
	public void setPaymentCreditCardCsvCode(int paymentCreditCardCsvCode) {
		this.paymentCreditCardCsvCode = paymentCreditCardCsvCode;
	}
	public int getPaymentCreditCardZipCode() {
		return paymentCreditCardZipCode;
	}
	public void setPaymentCreditCardZipCode(int paymentCreditCardZipCode) {
		this.paymentCreditCardZipCode = paymentCreditCardZipCode;
	}
	public String getPaymentCreditCardStatus() {
		return paymentCreditCardStatus;
	}
	public void setPaymentCreditCardStatus(String paymentCreditCardStatus) {
		this.paymentCreditCardStatus = paymentCreditCardStatus;
	}
}
