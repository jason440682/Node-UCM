package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.BusinessType;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BusinessTypeMapper implements RowMapper<BusinessType>{

	@Override
	public BusinessType mapRow(ResultSet rs, int rowNum) throws SQLException {
		BusinessType bt = new BusinessType();
		bt.setBusinessTypeId(rs.getInt("business_type_ID"));
		bt.setBusinessType(rs.getString("business_type"));
		return bt;
	}

}
