package indi.ucm.jdbc.entry;

//Info of billing for master user
public class MasterUserBilling {
	private long masterUserBillingId;
	private long masterUserPaymentCardId;
	
	public long getMasterUserBillingId() {
		return masterUserBillingId;
	}
	public void setMasterUserBillingId(long masterUserBillingId) {
		this.masterUserBillingId = masterUserBillingId;
	}
	public long getMasterUserPaymentCardId() {
		return masterUserPaymentCardId;
	}
	public void setMasterUserPaymentCardId(long masterUserPaymentCardId) {
		this.masterUserPaymentCardId = masterUserPaymentCardId;
	}
}
