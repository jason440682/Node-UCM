package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.TimeZone;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TimeZoneMapper implements RowMapper<TimeZone> {

    @Override
    public TimeZone mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        TimeZone tz = new TimeZone();
        tz.setTimeZoneId(rs.getInt("time_zone_ID"));
        tz.setTimeZoneLocation(rs.getString("timezone_location"));
        tz.setGmt(rs.getString("gmt"));
        tz.setOffset(rs.getShort("offset"));
        return tz;
    }

}
