package indi.ucm.jdbc.entry;

//Info of business type
public class BusinessType {
	private int businessTypeId;
	private String businessType;
	
	public int getBusinessTypeId() {
		return businessTypeId;
	}
	public void setBusinessTypeId(int businessTypeId) {
		this.businessTypeId = businessTypeId;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}	
}
