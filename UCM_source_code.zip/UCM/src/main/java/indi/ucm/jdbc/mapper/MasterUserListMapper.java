package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserList;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserListMapper implements RowMapper<MasterUserList>{

	@Override
	public MasterUserList mapRow(ResultSet rs, int rowNum) throws SQLException {
		MasterUserList mul = new MasterUserList();
		mul.setMasterUserId(rs.getInt("master_user_ID"));
		mul.setAccountServicePlan(rs.getInt("account_service_plan"));
		mul.setAccountServiceStatus(rs.getShort("account_status"));
		mul.setAccountCreatedDateTime(rs.getDate("account_created_date_time"));
		mul.setAccountBillingId(rs.getLong("account_billing_ID"));
		mul.setDatabaseTableNamePostfix(rs.getInt("database_table_name_postfix"));
		mul.setDescription(rs.getString("description"));
		mul.setUserName(rs.getString("username"));
		return mul;
	}

}
