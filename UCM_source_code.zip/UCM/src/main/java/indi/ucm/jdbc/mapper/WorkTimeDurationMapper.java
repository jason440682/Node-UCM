package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.WorkTimeDuration;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class WorkTimeDurationMapper implements RowMapper<WorkTimeDuration> {

    public WorkTimeDuration mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        WorkTimeDuration wtd = new WorkTimeDuration();
        wtd.setWorkTimeDurationId(rs.getInt("work_time_duration_ID"));
        wtd.setWorkTimeDuration(rs.getString("work_time_duration"));
        wtd.setWorkTimeDurationMinutes(rs.getInt("work_time_duration_minutes"));
        return wtd;
    }

}
