package indi.ucm.jdbc.entry;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

// Info of customer group notification
public class CustomerGroupNotification {
    private long customerGroupNotificationId;
    private String notificationName;
    private String description;
    private int recipients;
    private Date scheduleSendDate;
    private Time scheduleSendTime;
    private String emailSubjectLine;
    private String emailContent;
    private long emailAttachmentId;
    private String notificationStatus;
    private Timestamp actualSendDateTime;

    /**
     * @return the customerGroupNotificationId
     */
    public long getCustomerGroupNotificationId() {
        return this.customerGroupNotificationId;
    }

    /**
     * @param customerGroupNotificationId
     *            the customerGroupNotificationId to set
     */
    public void setCustomerGroupNotificationId(final long customerGroupNotificationId) {
        this.customerGroupNotificationId = customerGroupNotificationId;
    }

    /**
     * @return the notificationName
     */
    public String getNotificationName() {
        return this.notificationName;
    }

    /**
     * @param notificationName
     *            the notificationName to set
     */
    public void setNotificationName(final String notificationName) {
        this.notificationName = notificationName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * @return the recipients
     */
    public int getRecipients() {
        return this.recipients;
    }

    /**
     * @param recipients
     *            the recipients to set
     */
    public void setRecipients(final int recipients) {
        this.recipients = recipients;
    }

    /**
     * @return the scheduleSendDate
     */
    public Date getScheduleSendDate() {
        return this.scheduleSendDate;
    }

    /**
     * @param scheduleSendDate
     *            the scheduleSendDate to set
     */
    public void setScheduleSendDate(final Date scheduleSendDate) {
        this.scheduleSendDate = scheduleSendDate;
    }

    /**
     * @return the scheduleSendTime
     */
    public Time getScheduleSendTime() {
        return this.scheduleSendTime;
    }

    /**
     * @param scheduleSendTime
     *            the scheduleSendTime to set
     */
    public void setScheduleSendTime(final Time scheduleSendTime) {
        this.scheduleSendTime = scheduleSendTime;
    }

    /**
     * @return the emailSubjectLine
     */
    public String getEmailSubjectLine() {
        return this.emailSubjectLine;
    }

    /**
     * @param emailSubjectLine
     *            the emailSubjectLine to set
     */
    public void setEmailSubjectLine(final String emailSubjectLine) {
        this.emailSubjectLine = emailSubjectLine;
    }

    /**
     * @return the emailContent
     */
    public String getEmailContent() {
        return this.emailContent;
    }

    /**
     * @param emailContent
     *            the emailContent to set
     */
    public void setEmailContent(final String emailContent) {
        this.emailContent = emailContent;
    }

    /**
     * @return the emailAttachmentId
     */
    public long getEmailAttachmentId() {
        return this.emailAttachmentId;
    }

    /**
     * @param emailAttachmentId
     *            the emailAttachmentId to set
     */
    public void setEmailAttachmentId(final long emailAttachmentId) {
        this.emailAttachmentId = emailAttachmentId;
    }

    /**
     * @return the notificationStatus
     */
    public String getNotificationStatus() {
        return this.notificationStatus;
    }

    /**
     * @param notificationStatus
     *            the notificationStatus to set
     */
    public void setNotificationStatus(final String notificationStatus) {
        this.notificationStatus = notificationStatus;
    }

    /**
     * @return the actualSendDateTime
     */
    public Timestamp getActualSendDateTime() {
        return this.actualSendDateTime;
    }

    /**
     * @param actualSendDateTime
     *            the actualSendDateTime to set
     */
    public void setActualSendDateTime(final Timestamp actualSendDateTime) {
        this.actualSendDateTime = actualSendDateTime;
    }
}
