package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserAccountStatus;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserAccountStatusMapper implements RowMapper<MasterUserAccountStatus>{

	@Override
	public MasterUserAccountStatus mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		MasterUserAccountStatus muas = new MasterUserAccountStatus();
		muas.setAccountStatusId(rs.getInt("account_status_ID"));
		muas.setAccountStatus(rs.getString("account_status"));
		return muas;
	}

}
