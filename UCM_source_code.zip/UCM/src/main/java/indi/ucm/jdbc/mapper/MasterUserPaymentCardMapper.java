package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserPaymentCard;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserPaymentCardMapper implements RowMapper<MasterUserPaymentCard>{

	@Override
	public MasterUserPaymentCard mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		MasterUserPaymentCard mupc = new MasterUserPaymentCard();
		mupc.setMasterUserPaymentCardId(rs.getLong("master_user_payment_card_ID"));
		mupc.setPaymentCreditCardNumber(rs.getLong("payment_credit_card_number"));
		mupc.setPaymentCreditCardName(rs.getString("payment_credit_card_name"));
		mupc.setPaymentCreditCardExpirationMonth(rs.getInt("payment_credit_card_expiration_month"));
		mupc.setPayemntCreditCardExpirationYear(rs.getInt("payment_credit_card_expiration_year"));
		mupc.setPaymentCreditCardCsvCode(rs.getInt("payment_credit_card_csv_code"));
		mupc.setPaymentCreditCardZipCode(rs.getInt("payment_credit_card_zip_code"));
		mupc.setPaymentCreditCardStatus(rs.getString("payment_credit_card_status"));
		return mupc;
	}

}
