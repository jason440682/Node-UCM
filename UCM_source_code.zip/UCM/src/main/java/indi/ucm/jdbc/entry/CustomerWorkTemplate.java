package indi.ucm.jdbc.entry;

import java.sql.Date;
import java.sql.Time;

// Info of customer work template
public class CustomerWorkTemplate {
    private int customerWorkTemplateId;
    private String templateName;
    private int templateSectionId;
    private int assignStaffUser;
    private Date scheduleStartDate;
    private Date scheduleEndDate;
    private int workRepeatInterval;
    private Time scheduleStartTime;
    private Time scheduleEndTime;
    private int workTimeDuration;
    private int workLocationType;
    private int workClientContact;
    private String workDescription;
    private long workDocumentsId;
    private int workBillable;
    private int workBillingRate;
    private int workReminderNotifyStaff;
    private int workReminderNotifyStaffTime;
    private int workReminderNotifyStaffMethod;
    private int workReminderNotifyCustomer;
    private int workReminderNotifyCustomerTime;
    private int workReminderNotifyCustomerMethod;
    private String workReminderMessage;

    /**
     * @return the customerWorkTemplateId
     */
    public int getCustomerWorkTemplateId() {
        return this.customerWorkTemplateId;
    }

    /**
     * @param customerWorkTemplateId
     *            the customerWorkTemplateId to set
     */
    public void setCustomerWorkTemplateId(final int customerWorkTemplateId) {
        this.customerWorkTemplateId = customerWorkTemplateId;
    }

    /**
     * @return the templateName
     */
    public String getTemplateName() {
        return this.templateName;
    }

    /**
     * @param templateName
     *            the templateName to set
     */
    public void setTemplateName(final String templateName) {
        this.templateName = templateName;
    }

    /**
     * @return the templateSectionId
     */
    public int getTemplateSectionId() {
        return this.templateSectionId;
    }

    /**
     * @param templateSectionId
     *            the templateSectionId to set
     */
    public void setTemplateSectionId(final int templateSectionId) {
        this.templateSectionId = templateSectionId;
    }

    /**
     * @return the assignStaffUser
     */
    public int getAssignStaffUser() {
        return this.assignStaffUser;
    }

    /**
     * @param assignStaffUser
     *            the assignStaffUser to set
     */
    public void setAssignStaffUser(final int assignStaffUser) {
        this.assignStaffUser = assignStaffUser;
    }

    /**
     * @return the scheduleStartDate
     */
    public Date getScheduleStartDate() {
        return this.scheduleStartDate;
    }

    /**
     * @param scheduleStartDate
     *            the scheduleStartDate to set
     */
    public void setScheduleStartDate(final Date scheduleStartDate) {
        this.scheduleStartDate = scheduleStartDate;
    }

    /**
     * @return the scheduleEndDate
     */
    public Date getScheduleEndDate() {
        return this.scheduleEndDate;
    }

    /**
     * @param scheduleEndDate
     *            the scheduleEndDate to set
     */
    public void setScheduleEndDate(final Date scheduleEndDate) {
        this.scheduleEndDate = scheduleEndDate;
    }

    /**
     * @return the workRepeatInterval
     */
    public int getWorkRepeatInterval() {
        return this.workRepeatInterval;
    }

    /**
     * @param workRepeatInterval
     *            the workRepeatInterval to set
     */
    public void setWorkRepeatInterval(final int workRepeatInterval) {
        this.workRepeatInterval = workRepeatInterval;
    }

    /**
     * @return the scheduleStartTime
     */
    public Time getScheduleStartTime() {
        return this.scheduleStartTime;
    }

    /**
     * @param scheduleStartTime
     *            the scheduleStartTime to set
     */
    public void setScheduleStartTime(final Time scheduleStartTime) {
        this.scheduleStartTime = scheduleStartTime;
    }

    /**
     * @return the scheduleEndTime
     */
    public Time getScheduleEndTime() {
        return this.scheduleEndTime;
    }

    /**
     * @param scheduleEndTime
     *            the scheduleEndTime to set
     */
    public void setScheduleEndTime(final Time scheduleEndTime) {
        this.scheduleEndTime = scheduleEndTime;
    }

    /**
     * @return the workTimeDuration
     */
    public int getWorkTimeDuration() {
        return this.workTimeDuration;
    }

    /**
     * @param workTimeDuration
     *            the workTimeDuration to set
     */
    public void setWorkTimeDuration(final int workTimeDuration) {
        this.workTimeDuration = workTimeDuration;
    }

    /**
     * @return the workLocationType
     */
    public int getWorkLocationType() {
        return this.workLocationType;
    }

    /**
     * @param workLocationType
     *            the workLocationType to set
     */
    public void setWorkLocationType(final int workLocationType) {
        this.workLocationType = workLocationType;
    }

    /**
     * @return the workClientContact
     */
    public int getWorkClientContact() {
        return this.workClientContact;
    }

    /**
     * @param workClientContact
     *            the workClientContact to set
     */
    public void setWorkClientContact(final int workClientContact) {
        this.workClientContact = workClientContact;
    }

    /**
     * @return the workDescription
     */
    public String getWorkDescription() {
        return this.workDescription;
    }

    /**
     * @param workDescription
     *            the workDescription to set
     */
    public void setWorkDescription(final String workDescription) {
        this.workDescription = workDescription;
    }

    /**
     * @return the workDocumentsId
     */
    public long getWorkDocumentsId() {
        return this.workDocumentsId;
    }

    /**
     * @param workDocumentsId
     *            the workDocumentsId to set
     */
    public void setWorkDocumentsId(final long workDocumentsId) {
        this.workDocumentsId = workDocumentsId;
    }

    /**
     * @return the workBillable
     */
    public int getWorkBillable() {
        return this.workBillable;
    }

    /**
     * @param workBillable
     *            the workBillable to set
     */
    public void setWorkBillable(final int workBillable) {
        this.workBillable = workBillable;
    }

    /**
     * @return the workBillingRate
     */
    public int getWorkBillingRate() {
        return this.workBillingRate;
    }

    /**
     * @param workBillingRate
     *            the workBillingRate to set
     */
    public void setWorkBillingRate(final int workBillingRate) {
        this.workBillingRate = workBillingRate;
    }

    /**
     * @return the workReminderNotifyStaff
     */
    public int getWorkReminderNotifyStaff() {
        return this.workReminderNotifyStaff;
    }

    /**
     * @param workReminderNotifyStaff
     *            the workReminderNotifyStaff to set
     */
    public void setWorkReminderNotifyStaff(final int workReminderNotifyStaff) {
        this.workReminderNotifyStaff = workReminderNotifyStaff;
    }

    /**
     * @return the workReminderNotifyStaffTime
     */
    public int getWorkReminderNotifyStaffTime() {
        return this.workReminderNotifyStaffTime;
    }

    /**
     * @param workReminderNotifyStaffTime
     *            the workReminderNotifyStaffTime to set
     */
    public void setWorkReminderNotifyStaffTime(final int workReminderNotifyStaffTime) {
        this.workReminderNotifyStaffTime = workReminderNotifyStaffTime;
    }

    /**
     * @return the workReminderNotifyStaffMethod
     */
    public int getWorkReminderNotifyStaffMethod() {
        return this.workReminderNotifyStaffMethod;
    }

    /**
     * @param workReminderNotifyStaffMethod
     *            the workReminderNotifyStaffMethod to set
     */
    public void setWorkReminderNotifyStaffMethod(final int workReminderNotifyStaffMethod) {
        this.workReminderNotifyStaffMethod = workReminderNotifyStaffMethod;
    }

    /**
     * @return the workReminderNotifyCustomer
     */
    public int getWorkReminderNotifyCustomer() {
        return this.workReminderNotifyCustomer;
    }

    /**
     * @param workReminderNotifyCustomer
     *            the workReminderNotifyCustomer to set
     */
    public void setWorkReminderNotifyCustomer(final int workReminderNotifyCustomer) {
        this.workReminderNotifyCustomer = workReminderNotifyCustomer;
    }

    /**
     * @return the workReminderNotifyCustomerTime
     */
    public int getWorkReminderNotifyCustomerTime() {
        return this.workReminderNotifyCustomerTime;
    }

    /**
     * @param workReminderNotifyCustomerTime
     *            the workReminderNotifyCustomerTime to set
     */
    public void setWorkReminderNotifyCustomerTime(final int workReminderNotifyCustomerTime) {
        this.workReminderNotifyCustomerTime = workReminderNotifyCustomerTime;
    }

    /**
     * @return the workReminderNotifyCustomerMethod
     */
    public int getWorkReminderNotifyCustomerMethod() {
        return this.workReminderNotifyCustomerMethod;
    }

    /**
     * @param workReminderNotifyCustomerMethod
     *            the workReminderNotifyCustomerMethod to set
     */
    public void setWorkReminderNotifyCustomerMethod(final int workReminderNotifyCustomerMethod) {
        this.workReminderNotifyCustomerMethod = workReminderNotifyCustomerMethod;
    }

    /**
     * @return the workReminderMessage
     */
    public String getWorkReminderMessage() {
        return this.workReminderMessage;
    }

    /**
     * @param workReminderMessage
     *            the workReminderMessage to set
     */
    public void setWorkReminderMessage(final String workReminderMessage) {
        this.workReminderMessage = workReminderMessage;
    }
}
