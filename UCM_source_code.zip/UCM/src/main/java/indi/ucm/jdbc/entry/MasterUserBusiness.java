package indi.ucm.jdbc.entry;

// Info of Master user business
public class MasterUserBusiness {
    private long masterUserBusinessId;
    private String businessName;
    private int businessTypeId;
    private int businessTimeZoneId;
    private String businessEMail;
    private String businessPhoneNumber;
    private String busineseFaxNumber;
    private String businessAddressStreet;
    private String businessRoomNumber;
    private String businessAddressCity;
    private String businessAddressStateProvince;
    private String businessAddressZipCode;
    private int businessCountryId;
    private String businessDescription;

    /**
     * @return the masterUserBusinessId
     */
    public long getMasterUserBusinessId() {
        return this.masterUserBusinessId;
    }

    /**
     * @param masterUserBusinessId
     *            the masterUserBusinessId to set
     */
    public void setMasterUserBusinessId(final long masterUserBusinessId) {
        this.masterUserBusinessId = masterUserBusinessId;
    }

    /**
     * @return the businessName
     */
    public String getBusinessName() {
        return this.businessName;
    }

    /**
     * @param businessName
     *            the businessName to set
     */
    public void setBusinessName(final String businessName) {
        this.businessName = businessName;
    }

    /**
     * @return the businessTypeId
     */
    public int getBusinessTypeId() {
        return this.businessTypeId;
    }

    /**
     * @param businessTypeId
     *            the businessTypeId to set
     */
    public void setBusinessTypeId(final int businessTypeId) {
        this.businessTypeId = businessTypeId;
    }

    /**
     * @return the businessTimeZoneId
     */
    public int getBusinessTimeZoneId() {
        return this.businessTimeZoneId;
    }

    /**
     * @param businessTimeZoneId
     *            the businessTimeZoneId to set
     */
    public void setBusinessTimeZoneId(final int businessTimeZoneId) {
        this.businessTimeZoneId = businessTimeZoneId;
    }

    /**
     * @return the businessEMail
     */
    public String getBusinessEMail() {
        return this.businessEMail;
    }

    /**
     * @param businessEMail
     *            the businessEMail to set
     */
    public void setBusinessEMail(final String businessEMail) {
        this.businessEMail = businessEMail;
    }

    /**
     * @return the businessPhoneNumber
     */
    public String getBusinessPhoneNumber() {
        return this.businessPhoneNumber;
    }

    /**
     * @param businessPhoneNumber
     *            the businessPhoneNumber to set
     */
    public void setBusinessPhoneNumber(final String businessPhoneNumber) {
        this.businessPhoneNumber = businessPhoneNumber;
    }

    /**
     * @return the busineseFaxNumber
     */
    public String getBusineseFaxNumber() {
        return this.busineseFaxNumber;
    }

    /**
     * @param busineseFaxNumber
     *            the busineseFaxNumber to set
     */
    public void setBusineseFaxNumber(final String busineseFaxNumber) {
        this.busineseFaxNumber = busineseFaxNumber;
    }

    /**
     * @return the businessAddressStreet
     */
    public String getBusinessAddressStreet() {
        return this.businessAddressStreet;
    }

    /**
     * @param businessAddressStreet
     *            the businessAddressStreet to set
     */
    public void setBusinessAddressStreet(final String businessAddressStreet) {
        this.businessAddressStreet = businessAddressStreet;
    }

    /**
     * @return the businessRoomNumber
     */
    public String getBusinessRoomNumber() {
        return this.businessRoomNumber;
    }

    /**
     * @param businessRoomNumber
     *            the businessRoomNumber to set
     */
    public void setBusinessRoomNumber(final String businessRoomNumber) {
        this.businessRoomNumber = businessRoomNumber;
    }

    /**
     * @return the businessAddressCity
     */
    public String getBusinessAddressCity() {
        return this.businessAddressCity;
    }

    /**
     * @param businessAddressCity
     *            the businessAddressCity to set
     */
    public void setBusinessAddressCity(final String businessAddressCity) {
        this.businessAddressCity = businessAddressCity;
    }

    /**
     * @return the businessAddressStateProvince
     */
    public String getBusinessAddressStateProvince() {
        return this.businessAddressStateProvince;
    }

    /**
     * @param businessAddressStateProvince
     *            the businessAddressStateProvince to set
     */
    public void setBusinessAddressStateProvince(final String businessAddressStateProvince) {
        this.businessAddressStateProvince = businessAddressStateProvince;
    }

    
    
    public String getBusinessAddressZipCode() {
		return businessAddressZipCode;
	}

	public void setBusinessAddressZipCode(String businessAddressZipCode) {
		this.businessAddressZipCode = businessAddressZipCode;
	}

	/**
     * @return the businessCountryId
     */
    public int getBusinessCountryId() {
        return this.businessCountryId;
    }

    /**
     * @param businessCountryId
     *            the businessCountryId to set
     */
    public void setBusinessCountryId(final int businessCountryId) {
        this.businessCountryId = businessCountryId;
    }

    /**
     * @return the businessDescription
     */
    public String getBusinessDescription() {
        return this.businessDescription;
    }

    /**
     * @param businessDescription
     *            the businessDescription to set
     */
    public void setBusinessDescription(final String businessDescription) {
        this.businessDescription = businessDescription;
    }
}
