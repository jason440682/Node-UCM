package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.BusinessDepartment;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BusinessDepartmentMapper implements RowMapper<BusinessDepartment> {

    @Override
    public BusinessDepartment mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        BusinessDepartment bt = new BusinessDepartment();
        bt.setBusinessDepartmentId(rs.getInt("business_Department_ID"));
        bt.setBusinessDepartmentName(rs.getString("business_Department_name"));
        return bt;
    }

}
