package indi.ucm.jdbc.entry;

//Info of passcode receive device
public class PasscodeReceiveDevice {
	private int deviceId;
	private String deviceName;
	
	public int getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(int deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}	
}
