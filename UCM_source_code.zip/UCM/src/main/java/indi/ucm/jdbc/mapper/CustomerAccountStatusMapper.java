package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerAccountStatus;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerAccountStatusMapper implements RowMapper<CustomerAccountStatus> {

    @Override
    public CustomerAccountStatus mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerAccountStatus cas = new CustomerAccountStatus();
        cas.setCustomerAccountStatusId(rs.getInt("customer_account_status_ID"));
        cas.setAccountStatusName(rs.getString("account_status_name"));
        return cas;
    }

}
