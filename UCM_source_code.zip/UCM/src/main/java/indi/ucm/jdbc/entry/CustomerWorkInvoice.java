package indi.ucm.jdbc.entry;

import java.sql.Date;

// Info of customer work invoice
public class CustomerWorkInvoice {
    private long customerWorkInvoiceId;
    private long customerId;
    private String customerName;
    private Date invoiceDate;
    private double invoiceTotalAmount;
    private String billingAddressStreet;
    private String billingAddressRoomNumber;
    private String billingAddressCity;
    private String billingAddressStateProvince;
    private int billingAddressCountry;
    private String userNote;
    private int invoiceStatus;
    private long receivedPaymentId;

    /**
     * @return the customerWorkInvoiceId
     */
    public long getCustomerWorkInvoiceId() {
        return this.customerWorkInvoiceId;
    }

    /**
     * @param customerWorkInvoiceId
     *            the customerWorkInvoiceId to set
     */
    public void setCustomerWorkInvoiceId(final long customerWorkInvoiceId) {
        this.customerWorkInvoiceId = customerWorkInvoiceId;
    }

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the customerName
     */
    public String getCustomerName() {
        return this.customerName;
    }

    /**
     * @param customerName
     *            the customerName to set
     */
    public void setCustomerName(final String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the invoiceDate
     */
    public Date getInvoiceDate() {
        return this.invoiceDate;
    }

    /**
     * @param invoiceDate
     *            the invoiceDate to set
     */
    public void setInvoiceDate(final Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    /**
     * @return the invoiceTotalAmount
     */
    public double getInvoiceTotalAmount() {
        return this.invoiceTotalAmount;
    }

    /**
     * @param invoiceTotalAmount
     *            the invoiceTotalAmount to set
     */
    public void setInvoiceTotalAmount(final double invoiceTotalAmount) {
        this.invoiceTotalAmount = invoiceTotalAmount;
    }

    /**
     * @return the billingAddressStreet
     */
    public String getBillingAddressStreet() {
        return this.billingAddressStreet;
    }

    /**
     * @param billingAddressStreet
     *            the billingAddressStreet to set
     */
    public void setBillingAddressStreet(final String billingAddressStreet) {
        this.billingAddressStreet = billingAddressStreet;
    }

    /**
     * @return the billingAddressRoomNumber
     */
    public String getBillingAddressRoomNumber() {
        return this.billingAddressRoomNumber;
    }

    /**
     * @param billingAddressRoomNumber
     *            the billingAddressRoomNumber to set
     */
    public void setBillingAddressRoomNumber(final String billingAddressRoomNumber) {
        this.billingAddressRoomNumber = billingAddressRoomNumber;
    }

    /**
     * @return the billingAddressCity
     */
    public String getBillingAddressCity() {
        return this.billingAddressCity;
    }

    /**
     * @param billingAddressCity
     *            the billingAddressCity to set
     */
    public void setBillingAddressCity(final String billingAddressCity) {
        this.billingAddressCity = billingAddressCity;
    }

    /**
     * @return the billingAddressStateProvince
     */
    public String getBillingAddressStateProvince() {
        return this.billingAddressStateProvince;
    }

    /**
     * @param billingAddressStateProvince
     *            the billingAddressStateProvince to set
     */
    public void setBillingAddressStateProvince(final String billingAddressStateProvince) {
        this.billingAddressStateProvince = billingAddressStateProvince;
    }

    /**
     * @return the billingAddressCountry
     */
    public int getBillingAddressCountry() {
        return this.billingAddressCountry;
    }

    /**
     * @param billingAddressCountry
     *            the billingAddressCountry to set
     */
    public void setBillingAddressCountry(final int billingAddressCountry) {
        this.billingAddressCountry = billingAddressCountry;
    }

    /**
     * @return the userNote
     */
    public String getUserNote() {
        return this.userNote;
    }

    /**
     * @param userNote
     *            the userNote to set
     */
    public void setUserNote(final String userNote) {
        this.userNote = userNote;
    }

    /**
     * @return the invoiceStatus
     */
    public int getInvoiceStatus() {
        return this.invoiceStatus;
    }

    /**
     * @param invoiceStatus
     *            the invoiceStatus to set
     */
    public void setInvoiceStatus(final int invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    /**
     * @return the receivedPaymentId
     */
    public long getReceivedPaymentId() {
        return this.receivedPaymentId;
    }

    /**
     * @param receivedPaymentId
     *            the receivedPaymentId to set
     */
    public void setReceivedPaymentId(final long receivedPaymentId) {
        this.receivedPaymentId = receivedPaymentId;
    }
}
