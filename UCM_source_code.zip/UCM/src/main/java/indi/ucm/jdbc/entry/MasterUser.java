package indi.ucm.jdbc.entry;

public class MasterUser {
	private long masterUserId;
	private String uerName;
	private String hashedPassword;
	private String securityQuestion;
	private String securityQuestionAnswer;
	private String firstName;
	private String lastName;
	private String eMailAddress;
	private String phoneNumber;
	private String otherPhone;
	private int enable2FactorAuthenticationLogin;
	private int sendPasscodeToDeviceId;
	private int masterUserBusinessId;
	
	public long getMasterUserId() {
		return masterUserId;
	}
	public void setMasterUserId(long masterUserId) {
		this.masterUserId = masterUserId;
	}
	public String getUerName() {
		return uerName;
	}
	public void setUerName(String uerName) {
		this.uerName = uerName;
	}
	public String getHashedPassword() {
		return hashedPassword;
	}
	public void setHashedPassword(String hashedPassword) {
		this.hashedPassword = hashedPassword;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityQuestionAnswer() {
		return securityQuestionAnswer;
	}
	public void setSecurityQuestionAnswer(String securityQuestionAnswer) {
		this.securityQuestionAnswer = securityQuestionAnswer;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String geteMailAddress() {
		return eMailAddress;
	}
	public void seteMailAddress(String eMailAddress) {
		this.eMailAddress = eMailAddress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getOtherPhone() {
		return otherPhone;
	}
	public void setOtherPhone(String otherPhone) {
		this.otherPhone = otherPhone;
	}
	public int getEnable2FactorAuthenticationLogin() {
		return enable2FactorAuthenticationLogin;
	}
	public void setEnable2FactorAuthenticationLogin(
			int enable2FactorAuthenticationLogin) {
		this.enable2FactorAuthenticationLogin = enable2FactorAuthenticationLogin;
	}
	public int getSendPasscodeToDeviceId() {
		return sendPasscodeToDeviceId;
	}
	public void setSendPasscodeToDeviceId(int sendPasscodeToDeviceId) {
		this.sendPasscodeToDeviceId = sendPasscodeToDeviceId;
	}
	public int getMasterUserBusinessId() {
		return masterUserBusinessId;
	}
	public void setMasterUserBusinessId(int masterUserBusinessId) {
		this.masterUserBusinessId = masterUserBusinessId;
	}
}
