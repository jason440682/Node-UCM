package indi.ucm.jdbc.entry;

// Info of work locationType
public class WorkLocationType {
    private int workLocationType;
    private String LocationType;

    /**
     * @return the workLocationType
     */
    public int getWorkLocationType() {
        return this.workLocationType;
    }

    /**
     * @param workLocationType
     *            the workLocationType to set
     */
    public void setWorkLocationType(final int workLocationType) {
        this.workLocationType = workLocationType;
    }

    /**
     * @return the locationType
     */
    public String getLocationType() {
        return this.LocationType;
    }

    /**
     * @param locationType
     *            the locationType to set
     */
    public void setLocationType(final String locationType) {
        this.LocationType = locationType;
    }
}
