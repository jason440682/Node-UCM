package indi.ucm.jdbc.entry;

import java.sql.Timestamp;

// Info of Staff User
public class StaffUserBaseInfo {
    private int staffUserId;
    private int masterUserBusinessId;
    private String userName;
    private String firstName;
    private String lastName;
    private String eMailAddress;
    private String mobilePhone;
    private String otherPhone;
    private int enable2FactorAuthenticationLogin;
    private int sendPasscodeToDeviceId;
    private String jobTitle;
    private int businessDepartmentId;
    private int workTimeZone;
    private String workEmail;
    private String officePhone;
    private String officeAddressStreet;
    private String officeAddressRoomNumber;
    private String officeAddressCity;
    private String officeAddressStateProvince;
    private String officeAddressZipCode;
    private int officeAddressCountry;
    private String userNote;
    private Timestamp createdDateTime;
    private int enableAccess;

    /**
     * @return the staffUserId
     */
    public int getStaffUserId() {
        return this.staffUserId;
    }

    /**
     * @param staffUserId
     *            the staffUserId to set
     */
    public void setStaffUserId(final int staffUserId) {
        this.staffUserId = staffUserId;
    }

    /**
     * @return the masterUserBusinessId
     */
    public int getMasterUserBusinessId() {
        return this.masterUserBusinessId;
    }

    /**
     * @param masterUserBusinessId
     *            the masterUserBusinessId to set
     */
    public void setMasterUserBusinessId(final int masterUserBusinessId) {
        this.masterUserBusinessId = masterUserBusinessId;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return this.userName;
    }

    /**
     * @param userName
     *            the userName to set
     */
    public void setUserName(final String userName) {
        this.userName = userName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the eMailAddress
     */
    public String geteMailAddress() {
        return this.eMailAddress;
    }

    /**
     * @param eMailAddress
     *            the eMailAddress to set
     */
    public void seteMailAddress(final String eMailAddress) {
        this.eMailAddress = eMailAddress;
    }

    /**
     * @return the mobilePhone
     */
    public String getMobilePhone() {
        return this.mobilePhone;
    }

    /**
     * @param mobilePhone
     *            the mobilePhone to set
     */
    public void setMobilePhone(final String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    /**
     * @return the otherPhone
     */
    public String getOtherPhone() {
        return this.otherPhone;
    }

    /**
     * @param otherPhone
     *            the otherPhone to set
     */
    public void setOtherPhone(final String otherPhone) {
        this.otherPhone = otherPhone;
    }

    /**
     * @return the enable2FactorAuthenticationLogin
     */
    public int getEnable2FactorAuthenticationLogin() {
        return this.enable2FactorAuthenticationLogin;
    }

    /**
     * @param enable2FactorAuthenticationLogin
     *            the enable2FactorAuthenticationLogin to set
     */
    public void setEnable2FactorAuthenticationLogin(final int enable2FactorAuthenticationLogin) {
        this.enable2FactorAuthenticationLogin = enable2FactorAuthenticationLogin;
    }

    /**
     * @return the sendPasscodeToDeviceId
     */
    public int getSendPasscodeToDeviceId() {
        return this.sendPasscodeToDeviceId;
    }

    /**
     * @param sendPasscodeToDeviceId
     *            the sendPasscodeToDeviceId to set
     */
    public void setSendPasscodeToDeviceId(final int sendPasscodeToDeviceId) {
        this.sendPasscodeToDeviceId = sendPasscodeToDeviceId;
    }

    /**
     * @return the jobTitle
     */
    public String getJobTitle() {
        return this.jobTitle;
    }

    /**
     * @param jobTitle
     *            the jobTitle to set
     */
    public void setJobTitle(final String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * @return the businessDepartmentId
     */
    public int getBusinessDepartmentId() {
        return this.businessDepartmentId;
    }

    /**
     * @param businessDepartmentId
     *            the businessDepartmentId to set
     */
    public void setBusinessDepartmentId(final int businessDepartmentId) {
        this.businessDepartmentId = businessDepartmentId;
    }

    /**
     * @return the workTimeZone
     */
    public int getWorkTimeZone() {
        return this.workTimeZone;
    }

    /**
     * @param workTimeZone
     *            the workTimeZone to set
     */
    public void setWorkTimeZone(final int workTimeZone) {
        this.workTimeZone = workTimeZone;
    }

    /**
     * @return the workEmail
     */
    public String getWorkEmail() {
        return this.workEmail;
    }

    /**
     * @param workEmail
     *            the workEmail to set
     */
    public void setWorkEmail(final String workEmail) {
        this.workEmail = workEmail;
    }

    /**
     * @return the officePhone
     */
    public String getOfficePhone() {
        return this.officePhone;
    }

    /**
     * @param officePhone
     *            the officePhone to set
     */
    public void setOfficePhone(final String officePhone) {
        this.officePhone = officePhone;
    }

    /**
     * @return the officeAddressStreet
     */
    public String getOfficeAddressStreet() {
        return this.officeAddressStreet;
    }

    /**
     * @param officeAddressStreet
     *            the officeAddressStreet to set
     */
    public void setOfficeAddressStreet(final String officeAddressStreet) {
        this.officeAddressStreet = officeAddressStreet;
    }

    /**
     * @return the officeAddressRoomNumber
     */
    public String getOfficeAddressRoomNumber() {
        return this.officeAddressRoomNumber;
    }

    /**
     * @param officeAddressRoomNumber
     *            the officeAddressRoomNumber to set
     */
    public void setOfficeAddressRoomNumber(final String officeAddressRoomNumber) {
        this.officeAddressRoomNumber = officeAddressRoomNumber;
    }

    /**
     * @return the officeAddressCity
     */
    public String getOfficeAddressCity() {
        return this.officeAddressCity;
    }

    /**
     * @param officeAddressCity
     *            the officeAddressCity to set
     */
    public void setOfficeAddressCity(final String officeAddressCity) {
        this.officeAddressCity = officeAddressCity;
    }

    /**
     * @return the officeAddressStateProvince
     */
    public String getOfficeAddressStateProvince() {
        return this.officeAddressStateProvince;
    }

    /**
     * @param officeAddressStateProvince
     *            the officeAddressStateProvince to set
     */
    public void setOfficeAddressStateProvince(final String officeAddressStateProvince) {
        this.officeAddressStateProvince = officeAddressStateProvince;
    }

    
    
    public String getOfficeAddressZipCode() {
		return officeAddressZipCode;
	}

	public void setOfficeAddressZipCode(String officeAddressZipCode) {
		this.officeAddressZipCode = officeAddressZipCode;
	}

	/**
     * @return the officeAddressCountry
     */
    public int getOfficeAddressCountry() {
        return this.officeAddressCountry;
    }

    /**
     * @param officeAddressCountry
     *            the officeAddressCountry to set
     */
    public void setOfficeAddressCountry(final int officeAddressCountry) {
        this.officeAddressCountry = officeAddressCountry;
    }

    /**
     * @return the userNote
     */
    public String getUserNote() {
        return this.userNote;
    }

    /**
     * @param userNote
     *            the userNote to set
     */
    public void setUserNote(final String userNote) {
        this.userNote = userNote;
    }

    /**
     * @return the createdDateTime
     */
    public Timestamp getCreatedDateTime() {
        return this.createdDateTime;
    }

    /**
     * @param createdDateTime
     *            the createdDateTime to set
     */
    public void setCreatedDateTime(final Timestamp createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    /**
     * @return the enableAccess
     */
    public int getEnableAccess() {
        return this.enableAccess;
    }

    /**
     * @param enableAccess
     *            the enableAccess to set
     */
    public void setEnableAccess(final int enableAccess) {
        this.enableAccess = enableAccess;
    }
}
