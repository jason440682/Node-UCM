package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.BillingCurrency;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BillingCurrencyMapper implements RowMapper<BillingCurrency>{

	@Override
	public BillingCurrency mapRow(ResultSet rs, int rowNum) throws SQLException {
		BillingCurrency bc = new BillingCurrency();
		bc.setBillingCurrencyId(rs.getInt("billing_currency_ID"));
		bc.setIsoCode(rs.getString("iso_code"));
		bc.setSymbol(rs.getString("symbol"));
		bc.setUnicode(rs.getString("unicode"));
		bc.setPosition(rs.getString("position"));
		bc.setComments(rs.getString("comments"));
		return bc;
	}
	
}
