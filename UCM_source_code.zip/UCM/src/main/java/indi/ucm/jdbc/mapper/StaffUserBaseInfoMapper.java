package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.StaffUserBaseInfo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StaffUserBaseInfoMapper implements RowMapper<StaffUserBaseInfo> {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
     * int)
     */
    public StaffUserBaseInfo mapRow(final ResultSet rs, final int num) throws SQLException {
        StaffUserBaseInfo subi = new StaffUserBaseInfo();
        subi.setStaffUserId(rs.getInt("staff_user_ID"));
		subi.setMasterUserBusinessId(rs.getInt("master_user_business_ID"));
		subi.setUserName(rs.getString("username"));
		subi.setFirstName(rs.getString("first_name"));
		subi.setLastName(rs.getString("last_name"));
		subi.seteMailAddress(rs.getString("email_address"));
		subi.setMobilePhone(rs.getString("mobile_phone"));
		subi.setOtherPhone(rs.getString("other_phone"));
		subi.setEnable2FactorAuthenticationLogin(rs.getInt("enable_2_factor_authentication_login"));
		subi.setSendPasscodeToDeviceId(rs.getShort("send_passcode_to_device_ID"));
		subi.setJobTitle(rs.getString("job_title"));
		subi.setBusinessDepartmentId(rs.getInt("business_department_ID"));
		subi.setWorkTimeZone(rs.getInt("work_time_zone"));
		subi.setWorkEmail(rs.getString("work_email"));
		subi.setOfficePhone(rs.getString("office_phone"));
		subi.setOfficeAddressStreet(rs.getString("office_address_street"));
		subi.setOfficeAddressRoomNumber(rs.getString("office_address_room_number"));
		subi.setOfficeAddressCity(rs.getString("office_address_city"));
		subi.setOfficeAddressStateProvince(rs.getString("office_address_state_province"));
		subi.setOfficeAddressZipCode(rs.getString("business_address_zip_code"));
		subi.setOfficeAddressCountry(rs.getInt("office_addresss_country"));
		subi.setUserNote(rs.getString("user_note"));
		subi.setCreatedDateTime(rs.getTimestamp("created_date_time"));
		subi.setEnableAccess(rs.getInt("enable_access"));
        return subi;
    }

}
