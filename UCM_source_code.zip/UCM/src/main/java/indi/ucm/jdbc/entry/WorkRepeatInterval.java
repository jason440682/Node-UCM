package indi.ucm.jdbc.entry;

// Info of work repeat interval
public class WorkRepeatInterval {
    private int workRepeatIntervalId;
    private String repeatIntervalName;
    private int repeatIntervalMinutes;

    /**
     * @return the workRepeatIntervalId
     */
    public int getWorkRepeatIntervalId() {
        return this.workRepeatIntervalId;
    }

    /**
     * @param workRepeatIntervalId
     *            the workRepeatIntervalId to set
     */
    public void setWorkRepeatIntervalId(final int workRepeatIntervalId) {
        this.workRepeatIntervalId = workRepeatIntervalId;
    }

    /**
     * @return the repeatIntervalName
     */
    public String getRepeatIntervalName() {
        return this.repeatIntervalName;
    }

    /**
     * @param repeatIntervalName
     *            the repeatIntervalName to set
     */
    public void setRepeatIntervalName(final String repeatIntervalName) {
        this.repeatIntervalName = repeatIntervalName;
    }

    /**
     * @return the repeatIntervalMinutes
     */
    public int getRepeatIntervalMinutes() {
        return this.repeatIntervalMinutes;
    }

    /**
     * @param repeatIntervalMinutes
     *            the repeatIntervalMinutes to set
     */
    public void setRepeatIntervalMinutes(final int repeatIntervalMinutes) {
        this.repeatIntervalMinutes = repeatIntervalMinutes;
    }
}
