package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerNotificationPreference;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerNotificationPreferenceMapper implements RowMapper<CustomerNotificationPreference> {

    @Override
    public CustomerNotificationPreference mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerNotificationPreference cnp = new CustomerNotificationPreference();
        cnp.setNotificationPreferenceId(rs.getInt("notification_preference_ID"));
        cnp.setNotificationPreferenceName(rs.getString("notification_preference_name"));
        return cnp;
    }

}
