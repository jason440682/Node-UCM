package indi.ucm.jdbc.entry;

//Info of service plan for master user
public class MasterUserServicePlan {
	private int servicePlanId;
	private String servicePlan;
	
	public int getServicePlanId() {
		return servicePlanId;
	}
	public void setServicePlanId(int servicePlanId) {
		this.servicePlanId = servicePlanId;
	}
	public String getServicePlan() {
		return servicePlan;
	}
	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}
}
