package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserBilling;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserBillingMapper implements RowMapper<MasterUserBilling>{

	@Override
	public MasterUserBilling mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		MasterUserBilling mub = new MasterUserBilling();
		mub.setMasterUserBillingId(rs.getLong("master_user_billing_ID"));
		mub.setMasterUserPaymentCardId(rs.getLong("master_user_payment_card_ID"));
		return mub;
	}
	

}
