package indi.ucm.jdbc.entry;

public class MasterUserInfo {
	private long masterUserId;
	private String userName;
	private String firstName;
	private String lastName;
	private String eMailAddress;
	private String phoneNumber;
	private String otherPhone;
	private int enable2FactorAuthenticationLogin;
	private int sendPasscodeToDeviceId;
	private int masterUserBusinessId;
	private String businessName;
    private int businessTypeId;
    private int businessTimeZoneId;
    private String businessEMail;
    private String businessPhoneNumber;
    private String busineseFaxNumber;
    private String businessAddressStreet;
    private String businessRoomNumber;
    private String businessAddressCity;
    private String businessAddressStateProvince;
    private String businessAddressZipCode;
    private int businessCountryId;
    private String businessDescription;
	public long getMasterUserId() {
		return masterUserId;
	}
	public void setMasterUserId(long masterUserId) {
		this.masterUserId = masterUserId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String geteMailAddress() {
		return eMailAddress;
	}
	public void seteMailAddress(String eMailAddress) {
		this.eMailAddress = eMailAddress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getOtherPhone() {
		return otherPhone;
	}
	public void setOtherPhone(String otherPhone) {
		this.otherPhone = otherPhone;
	}
	public int getEnable2FactorAuthenticationLogin() {
		return enable2FactorAuthenticationLogin;
	}
	public void setEnable2FactorAuthenticationLogin(
			int enable2FactorAuthenticationLogin) {
		this.enable2FactorAuthenticationLogin = enable2FactorAuthenticationLogin;
	}
	public int getSendPasscodeToDeviceId() {
		return sendPasscodeToDeviceId;
	}
	public void setSendPasscodeToDeviceId(int sendPasscodeToDeviceId) {
		this.sendPasscodeToDeviceId = sendPasscodeToDeviceId;
	}
	public int getMasterUserBusinessId() {
		return masterUserBusinessId;
	}
	public void setMasterUserBusinessId(int masterUserBusinessId) {
		this.masterUserBusinessId = masterUserBusinessId;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public int getBusinessTypeId() {
		return businessTypeId;
	}
	public void setBusinessTypeId(int businessTypeId) {
		this.businessTypeId = businessTypeId;
	}
	public int getBusinessTimeZoneId() {
		return businessTimeZoneId;
	}
	public void setBusinessTimeZoneId(int businessTimeZoneId) {
		this.businessTimeZoneId = businessTimeZoneId;
	}
	public String getBusinessEMail() {
		return businessEMail;
	}
	public void setBusinessEMail(String businessEMail) {
		this.businessEMail = businessEMail;
	}
	public String getBusinessPhoneNumber() {
		return businessPhoneNumber;
	}
	public void setBusinessPhoneNumber(String businessPhoneNumber) {
		this.businessPhoneNumber = businessPhoneNumber;
	}
	public String getBusineseFaxNumber() {
		return busineseFaxNumber;
	}
	public void setBusineseFaxNumber(String busineseFaxNumber) {
		this.busineseFaxNumber = busineseFaxNumber;
	}
	public String getBusinessAddressStreet() {
		return businessAddressStreet;
	}
	public void setBusinessAddressStreet(String businessAddressStreet) {
		this.businessAddressStreet = businessAddressStreet;
	}
	public String getBusinessRoomNumber() {
		return businessRoomNumber;
	}
	public void setBusinessRoomNumber(String businessRoomNumber) {
		this.businessRoomNumber = businessRoomNumber;
	}
	public String getBusinessAddressCity() {
		return businessAddressCity;
	}
	public void setBusinessAddressCity(String businessAddressCity) {
		this.businessAddressCity = businessAddressCity;
	}
	public String getBusinessAddressStateProvince() {
		return businessAddressStateProvince;
	}
	public void setBusinessAddressStateProvince(String businessAddressStateProvince) {
		this.businessAddressStateProvince = businessAddressStateProvince;
	}
	
	public String getBusinessAddressZipCode() {
		return businessAddressZipCode;
	}
	public void setBusinessAddressZipCode(String businessAddressZipCode) {
		this.businessAddressZipCode = businessAddressZipCode;
	}
	public int getBusinessCountryId() {
		return businessCountryId;
	}
	public void setBusinessCountryId(int businessCountryId) {
		this.businessCountryId = businessCountryId;
	}
	public String getBusinessDescription() {
		return businessDescription;
	}
	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}
}
