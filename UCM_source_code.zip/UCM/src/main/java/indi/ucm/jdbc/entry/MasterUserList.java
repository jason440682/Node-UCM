package indi.ucm.jdbc.entry;

import java.util.Date;

//Info of Master users
public class MasterUserList {
	private int masterUserId;
	private int accountServicePlan;
	private int accountServiceStatus;
	private Date accountCreatedDateTime;
	private long accountBillingId;
	private long databaseTableNamePostfix;
	private String description;
	private String userName;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getMasterUserId() {
		return masterUserId;
	}
	public void setMasterUserId(int masterUserId) {
		this.masterUserId = masterUserId;
	}
	public int getAccountServicePlan() {
		return accountServicePlan;
	}
	public void setAccountServicePlan(int accountServicePlan) {
		this.accountServicePlan = accountServicePlan;
	}
	public int getAccountServiceStatus() {
		return accountServiceStatus;
	}
	public void setAccountServiceStatus(int accountServiceStatus) {
		this.accountServiceStatus = accountServiceStatus;
	}
	public Date getAccountCreatedDateTime() {
		return accountCreatedDateTime;
	}
	public void setAccountCreatedDateTime(Date accountCreatedDateTime) {
		this.accountCreatedDateTime = accountCreatedDateTime;
	}
	public long getAccountBillingId() {
		return accountBillingId;
	}
	public void setAccountBillingId(long accountBillingId) {
		this.accountBillingId = accountBillingId;
	}
	public long getDatabaseTableNamePostfix() {
		return databaseTableNamePostfix;
	}
	public void setDatabaseTableNamePostfix(int databaseTableNamePostfix) {
		this.databaseTableNamePostfix = databaseTableNamePostfix;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
