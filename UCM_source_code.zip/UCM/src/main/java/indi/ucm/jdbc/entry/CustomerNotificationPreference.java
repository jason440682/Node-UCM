package indi.ucm.jdbc.entry;

// Info of customer notification preference
public class CustomerNotificationPreference {
    private int notificationPreferenceId;
    private String notificationPreferenceName;

    /**
     * @return the notificationPreferenceId
     */
    public int getNotificationPreferenceId() {
        return this.notificationPreferenceId;
    }

    /**
     * @param notificationPreferenceId
     *            the notificationPreferenceId to set
     */
    public void setNotificationPreferenceId(final int notificationPreferenceId) {
        this.notificationPreferenceId = notificationPreferenceId;
    }

    /**
     * @return the notificationPreferenceName
     */
    public String getNotificationPreferenceName() {
        return this.notificationPreferenceName;
    }

    /**
     * @param notificationPreferenceName
     *            the notificationPreferenceName to set
     */
    public void setNotificationPreferenceName(final String notificationPreferenceName) {
        this.notificationPreferenceName = notificationPreferenceName;
    }
}
