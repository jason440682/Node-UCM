package indi.ucm.jdbc.entry;

// Info of work time duration
public class WorkTimeDuration {
    private int workTimeDurationId;
    private String workTimeDuration;
    private int workTimeDurationMinutes;

    /**
     * @return the workTimeDurationId
     */
    public int getWorkTimeDurationId() {
        return this.workTimeDurationId;
    }

    /**
     * @param workTimeDurationId
     *            the workTimeDurationId to set
     */
    public void setWorkTimeDurationId(final int workTimeDurationId) {
        this.workTimeDurationId = workTimeDurationId;
    }

    /**
     * @return the workTimeDuration
     */
    public String getWorkTimeDuration() {
        return this.workTimeDuration;
    }

    /**
     * @param workTimeDuration
     *            the workTimeDuration to set
     */
    public void setWorkTimeDuration(final String workTimeDuration) {
        this.workTimeDuration = workTimeDuration;
    }

    /**
     * @return the workTimeDurationMinutes
     */
    public int getWorkTimeDurationMinutes() {
        return this.workTimeDurationMinutes;
    }

    /**
     * @param workTimeDurationMinutes
     *            the workTimeDurationMinutes to set
     */
    public void setWorkTimeDurationMinutes(final int workTimeDurationMinutes) {
        this.workTimeDurationMinutes = workTimeDurationMinutes;
    }
}
