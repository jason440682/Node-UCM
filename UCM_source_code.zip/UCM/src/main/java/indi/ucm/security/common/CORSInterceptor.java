package indi.ucm.security.common;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class CORSInterceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {

	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2, ModelAndView arg3) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res,
			Object obj) throws Exception {
		String[] allowDomain = { "http://localhost:3331", "http://54.169.159.192:3331", "http://localhost:3333"};
		Set<String> allowedOrigins = new HashSet<String>(
				Arrays.asList(allowDomain));
		String originHeader = ((HttpServletRequest) req).getHeader("Origin");
		if (allowedOrigins.contains(originHeader)) {
			((HttpServletResponse) res).setHeader(
					"Access-Control-Allow-Origin", originHeader);
		}
		return true;
	}

}
