package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerAccountStatusDao;
import indi.ucm.jdbc.dao.CustomerAccountTypeDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerEmailGroupDao;
import indi.ucm.jdbc.dao.CustomerNotificationPreferenceDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerInfo;
import indi.ucm.security.common.GenerateRandomIdHelper;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateCustomerAccountRestController {

	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	CustomerAccountDao customerAccountDao;
	@Autowired
	CustomerAccountTypeDao customerAccountTypeDao;
	@Autowired
	CustomerAccountStatusDao customerAccountStatusDao;
	@Autowired
	CustomerNotificationPreferenceDao customerNotificationPreferenceDao;
	@Autowired
	CustomerEmailGroupDao customerEmailGroupDao;
	@Autowired
	CustomerBusinessDao customerBusinessDao;

	// -------------------Create a customer account-----------------------
	@RequestMapping(value = "/CreateCustomerAccount", method = RequestMethod.POST)
	public ResponseEntity<String> createCustomerAccount(
			final HttpServletRequest request) {
		// store data from request
		String userName = request.getParameter("userName");
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		try {
			stroeCustomerAccountInfo(request, masterUserId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Duplicated user name",
					HttpStatus.SERVICE_UNAVAILABLE);
		}

		return new ResponseEntity<String>("Create staff user Successfully",
				HttpStatus.OK);
	}

	// -------------------get a customer account-----------------------
	@RequestMapping(value = "/GetClient", method = RequestMethod.POST)
	public ResponseEntity<CustomerInfo> modifyCustomerAccount(
			final HttpServletRequest request) {
		
		String userName = request.getParameter("userName");
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		int customerId = Integer.parseInt(request.getParameter("customerId"));

		CustomerAccount ca = customerAccountDao.getCustomerAccount(customerId,
				masterUserId);
		CustomerInfo ci = new CustomerInfo();
		if (ca.getCustomerAccountType() == 2) {
			CustomerBusiness cb = customerBusinessDao
					.getCustomerBusinessByBusinessId(
							ca.getCustomerBusinessId(), masterUserId);
			ci.setBusinessName(cb.getBusinessName());
		}
		;
		ci.setCustomerId(ca.getCustomerId());
		ci.setCustomerBusinessId(ca.getCustomerBusinessId());
		ci.setCustomerAccountType(ca.getCustomerAccountType());
		ci.setFirstName(ca.getFirstName());
		ci.setLastName(ca.getLastName());
		ci.setCustomerAccountStatus(ca.getCustomerAccountStatus());
		ci.setAssignedStaffUser(ca.getAssignedStaffUser());
		ci.setcFirstName(ca.getcFirstName());
		ci.setcLastName(ca.getcLastName());
		ci.setEmailAddress(ca.getEmailAddress());
		ci.setMobilePhone(ca.getMobilePhone());
		ci.setMailingAddressStreet(ca.getMailingAddressStreet());
		ci.setMailingAddressCity(ca.getMailingAddressCity());
		ci.setMailingAddressStateProvince(ca.getMailingAddressStateProvince());
		ci.setMailingAddressZipCode(ca.getMailingAddressZipCode());
		ci.setMailingAddressCountry(ca.getMailingAddressCountry());
		ci.setBillingAddressStreet(ca.getBillingAddressStreet());
		ci.setBillingAddressCity(ca.getBillingAddressCity());
		ci.setBillingAddressStateProvince(ca.getBillingAddressStateProvince());
		ci.setBillingAddressZipCode(ca.getBillingAddressZipCode());
		ci.setBillingAddressCountry(ca.getBillingAddressCountry());
		ci.setCustomerNote(ca.getCustomerNote());
		ci.setEmailGroup(ca.getEmailGroup());
		if (ca.getNotificationPreference() == 10) {
			ci.setNotificationPreference("010");
		} else if (ca.getNotificationPreference() == 1) {
			ci.setNotificationPreference("001");
		} else {
			ci.setNotificationPreference(String.valueOf(ca
					.getNotificationPreference()));
		}
		ci.setEnableClientPortal(ca.getEnableClientPortal());

		return new ResponseEntity<CustomerInfo>(ci, HttpStatus.OK);
	}

	// -------------------Get all customer account types-----------------------
	@RequestMapping(value = "/getCustomerAccountTypes/{userName}", method = RequestMethod.GET)
	public ResponseEntity<List> getCustomerAccountTypes(
			@PathVariable("userName") final String userName) {
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		List cats = this.customerAccountTypeDao
				.getCustomerAccountTypes(masterUserId);

		return new ResponseEntity<List>(cats, HttpStatus.OK);
	}

	// -------------------Get all customer account statuss--------------------
	@RequestMapping(value = "/getCustomerAccountStatuss/{userName}", method = RequestMethod.GET)
	public ResponseEntity<List> getCustomerAccountStatuss(
			@PathVariable("userName") final String userName) {
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		List cass = this.customerAccountStatusDao
				.getCustomerAccountStatuss(masterUserId);

		return new ResponseEntity<List>(cass, HttpStatus.OK);
	}

	// -------------------Get all customer notification references------------
	@RequestMapping(value = "/getCustomerNotificationPreferences/{userName}", method = RequestMethod.GET)
	public ResponseEntity<List> getCustomerNotificationPreferences(
			@PathVariable("userName") final String userName) {
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		List cnps = this.customerNotificationPreferenceDao
				.getCustomerNotificationPreferences(masterUserId);

		return new ResponseEntity<List>(cnps, HttpStatus.OK);
	}

	// -------------------Get all customer email groups------------
	@RequestMapping(value = "/getCustomerEmailGroups/{userName}", method = RequestMethod.GET)
	public ResponseEntity<List> getCustomerEmailGroups(
			@PathVariable("userName") final String userName) {
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		List cegs = this.customerEmailGroupDao
				.getCustomerEmailGroups(masterUserId);

		return new ResponseEntity<List>(cegs, HttpStatus.OK);
	}

	/**
	 * generate customer ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private long generateCustomerId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		long customerId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			customerId = GenerateRandomIdHelper.generateRandomNumber(8);
			isUnique = isCustomerAccountUniqueId(customerId, masterUserId);
		}
		return customerId;
	}

	/**
	 * verify whether the customer account ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isCustomerAccountUniqueId(final long customerId,
			final int masterUserId) {
		CustomerAccount CustomerAccount = this.customerAccountDao
				.getCustomerAccount(customerId, masterUserId);
		if (CustomerAccount == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * generate customer Business ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private long generateCustomerBusinessId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		long customerBusinessId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			customerBusinessId = GenerateRandomIdHelper.generateRandomNumber(8);
			isUnique = isCustomerBusinessUniqueId(customerBusinessId,
					masterUserId);
		}
		return customerBusinessId;
	}

	/**
	 * verify whether the customer business ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isCustomerBusinessUniqueId(final long customerBusinessId,
			final int masterUserId) {
		CustomerAccount CustomerAccount = this.customerAccountDao
				.getCustomerAccountByBusinessId(customerBusinessId,
						masterUserId);
		if (CustomerAccount == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * store info of customer account from request
	 * 
	 * @param request
	 * @param tableName
	 * @throws Exception
	 */
	private void stroeCustomerAccountInfo(final HttpServletRequest request,
			final int masterUserId) throws Exception {
		CustomerAccount customerAccount = new CustomerAccount();
		long customerId = generateCustomerId(masterUserId);
		long customerBusinessId = generateCustomerBusinessId(masterUserId);
		customerAccount.setCustomerId(customerId);
		customerAccount.setCustomerBusinessId(customerBusinessId);
		int customerAccountType = Integer.parseInt(request
				.getParameter("customerAccountType"));
		customerAccount.setCustomerAccountType(customerAccountType);
		switch (customerAccountType) {
		case 1: {
			customerAccount.setFirstName(request.getParameter("firstName"));
			customerAccount.setLastName(request.getParameter("lastName"));
		}
			break;
		case 2: {
			CustomerBusiness customerBusiness = new CustomerBusiness();
			customerBusiness.setCustomerBusinessId(customerBusinessId);
			customerBusiness.setCustomerId(customerId);
			customerBusiness.setBusinessName(request
					.getParameter("businessName"));
			customerBusinessDao.createCustomerBusiness(customerBusiness,
					masterUserId);
		}
			break;
		}
		customerAccount.setCustomerAccountStatus(Integer.parseInt(request
				.getParameter("customerAccountStatus")));
		customerAccount.setAssignedStaffUser(Integer.parseInt(request
				.getParameter("assignedStaffUser")));
		customerAccount.setcFirstName(request.getParameter("cFirstName"));
		customerAccount.setcLastName(request.getParameter("cLastName"));
		customerAccount.setEmailAddress(request.getParameter("emailAddress"));
		customerAccount.setMobilePhone(request.getParameter("mobilePhone"));
		customerAccount.setMailingAddressStreet(request
				.getParameter("mailingAddressStreet"));
		customerAccount.setMailingAddressRoomNumber("N/A");
		customerAccount.setMailingAddressCity(request
				.getParameter("mailingAddressCity"));
		customerAccount.setMailingAddressStateProvince(request
				.getParameter("mailingAddressStateProvince"));
		customerAccount.setMailingAddressZipCode(request
				.getParameter("mailingAddressZipCode"));
		customerAccount.setMailingAddressCountry(Integer.parseInt(request
				.getParameter("mailingAddressCountry")));
		customerAccount.setBillingAddressStreet(request
				.getParameter("billingAddressStreet"));
		customerAccount.setBillingAddressRoomNumber("N/A");
		customerAccount.setBillingAddressCity(request
				.getParameter("billingAddressCity"));
		customerAccount.setBillingAddressStateProvince(request
				.getParameter("billingAddressStateProvince"));
		customerAccount.setBillingAddressZipCode(request
				.getParameter("billingAddressZipCode"));
		customerAccount.setBillingAddressCountry(Integer.parseInt(request
				.getParameter("billingAddressCountry")));
		customerAccount.setCustomerNote(request.getParameter("customerNote"));
		customerAccount.setEmailGroup(Integer.parseInt(request
				.getParameter("emailGroup")));
		customerAccount.setNotificationPreference(Integer.parseInt(request
				.getParameter("notificationPreference")));
		customerAccount.setEnableClientPortal(Integer.parseInt(request
				.getParameter("enableClientPortal")));
		customerAccount.setClientPortalUserName("N/A");
		customerAccount.setHashedPassword("N/A");
		customerAccount.setSecurityQuestion("N/A");
		customerAccount.setSecurityQuestionAnswer("N/A");
		customerAccount.setSendPasscodeToDeviceId(0);
		customerAccount.setEnable2FactorAuthenticationLogin(0);

		this.customerAccountDao.createCustomerAccount(customerAccount,
				masterUserId);

	}
}
