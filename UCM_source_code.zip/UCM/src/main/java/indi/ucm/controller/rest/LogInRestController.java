package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.MasterUserList;
import indi.ucm.security.common.EncryptionDecryption;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogInRestController {
    // Service which will do all data retrieval/manipulation work
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    MasterUserListDao masterUserListDao;

    // -------------------master user login API-----------------------
    @RequestMapping(value = "/LogIn", method = RequestMethod.POST)
    public ResponseEntity<String> signUpMasterUser(final HttpServletRequest request) {
        // verify login request
        Boolean isAuthenticated = authenticateRequest(request);
        if (isAuthenticated) {
            return new ResponseEntity<String>("Authenticated", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("Failed Authentication", HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * verify Login request
     * 
     * @param request
     * @return
     */
    private Boolean authenticateRequest(final HttpServletRequest request) {
        MasterUserList mul = this.masterUserListDao.getMasterUserListByName(request.getParameter("userName"));
        if (mul != null) {
            MasterUser mu = this.masterUserDao.getMasterUser(mul.getMasterUserId());
            String userName = request.getParameter("userName");
            String password = request.getParameter("hashedPassword");
            if (mu != null && userName != null && password != null && userName.equals(mu.getUerName())
                && password.equals(EncryptionDecryption.decryptStr(mu.getHashedPassword()))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
