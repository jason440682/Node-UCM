package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.MasterUserBusinessDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.MasterUserBusiness;
import indi.ucm.jdbc.entry.MasterUserInfo;
import indi.ucm.security.common.EncryptionDecryption;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ModifyMasterUserRestController {
	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	MasterUserBusinessDao masterUserBusinessDao;

	// -------------------Retrieve master user---------------
	@RequestMapping(value = "/GetMasterUser/{userName}", method = RequestMethod.GET)
	public ResponseEntity<MasterUserInfo> getStaffUsers(
			@PathVariable("userName") final String userName) {
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();
		MasterUser mu = masterUserDao.getMasterUser(masterUserId);
		MasterUserInfo mui = new MasterUserInfo();

		if (mu == null) {
			return new ResponseEntity<MasterUserInfo>(mui, HttpStatus.OK);
		} else {
			MasterUserBusiness mub = masterUserBusinessDao
					.getMasterUserBusiness(mu.getMasterUserBusinessId(),
							masterUserId);
			mui.setMasterUserId(masterUserId);
			mui.setUserName(mu.getUerName());
			mui.setFirstName(mu.getFirstName());
			mui.setLastName(mu.getLastName());
			mui.seteMailAddress(mu.geteMailAddress());
			mui.setPhoneNumber(mu.getPhoneNumber());
			mui.setOtherPhone(mu.getOtherPhone());
			mui.setEnable2FactorAuthenticationLogin(mu
					.getEnable2FactorAuthenticationLogin());
			mui.setSendPasscodeToDeviceId(mu.getSendPasscodeToDeviceId());
			mui.setMasterUserBusinessId(mu.getMasterUserBusinessId());
			mui.setBusinessName(mub.getBusinessName());
			mui.setBusinessTypeId(mub.getBusinessTypeId());
			mui.setBusinessTimeZoneId(mub.getBusinessTimeZoneId());
			mui.setBusinessEMail(mub.getBusinessEMail());
			mui.setBusinessPhoneNumber(mub.getBusinessPhoneNumber());
			mui.setBusineseFaxNumber("TBD");
			mui.setBusinessAddressStreet(mub.getBusinessAddressStreet());
			mui.setBusinessRoomNumber("TBD");
			mui.setBusinessAddressCity(mub.getBusinessAddressCity());
			mui.setBusinessAddressStateProvince(mub
					.getBusinessAddressStateProvince());
			mui.setBusinessAddressZipCode(mub.getBusinessAddressZipCode());
			mui.setBusinessCountryId(mub.getBusinessCountryId());
			mui.setBusinessDescription(mub.getBusinessDescription());

			return new ResponseEntity<MasterUserInfo>(mui, HttpStatus.OK);
		}
	}

	// -------------------modify a masterUser-----------------------
	@RequestMapping(value = "/ModifyMasterUser", method = RequestMethod.POST)
	public ResponseEntity<String> modifyMasterUser(
			final HttpServletRequest request) {
		// store data from request
		String userName = request.getParameter("userName");
		int masterUserId = this.masterUserListDao.getMasterUserListByName(
				userName).getMasterUserId();

		updateMasterUserInfo(request, masterUserId);

		return new ResponseEntity<String>("Modify master user Successfully",
				HttpStatus.OK);
	}

	private void updateMasterUserInfo(HttpServletRequest request,
			int masterUserId) {
		MasterUserBusiness masterUserBusiness = new MasterUserBusiness();
		masterUserBusiness
		.setMasterUserBusinessId(Integer.parseInt(request.getParameter("masterUserBusinessId")));
		masterUserBusiness
				.setBusinessName(request.getParameter("businessName"));
		masterUserBusiness.setBusinessTypeId(Integer.parseInt(request
				.getParameter("businessTypeId")));
		masterUserBusiness.setBusinessTimeZoneId(Integer.parseInt(request
				.getParameter("businessTimeZoneId")));
		masterUserBusiness.setBusinessEMail(request
				.getParameter("businessEMail"));
		masterUserBusiness.setBusinessPhoneNumber(request
				.getParameter("businessPhoneNumber"));
		masterUserBusiness.setBusineseFaxNumber(request
				.getParameter("businessFaxNumber"));
		masterUserBusiness.setBusinessAddressStreet(request
				.getParameter("businessAddressStreet"));
		masterUserBusiness.setBusinessRoomNumber(request
				.getParameter("businessRoomNumber"));
		masterUserBusiness.setBusinessAddressCity(request
				.getParameter("businessAddressCity"));
		masterUserBusiness.setBusinessAddressStateProvince(request
				.getParameter("businessAddressStateProvince"));
		masterUserBusiness.setBusinessCountryId(Integer.parseInt(request
				.getParameter("businessCountryId")));
		masterUserBusiness.setBusinessAddressZipCode(request.getParameter("businessAddressZipCode"));
		masterUserBusiness.setBusinessDescription(request
				.getParameter("businessDescription"));
		masterUserBusinessDao.modifyMasterUserBusiness(masterUserBusiness,
				masterUserId);

		MasterUser masterUser = new MasterUser();
		masterUser.setMasterUserId(masterUserId);
		masterUser.setFirstName(request.getParameter("firstName"));
		masterUser.setLastName(request.getParameter("lastName"));
		masterUser.seteMailAddress(request.getParameter("eMailAddress"));
		masterUser.setPhoneNumber(request.getParameter("phoneNumber"));
		masterUser.setOtherPhone(request.getParameter("otherPhone"));
		masterUser.setEnable2FactorAuthenticationLogin(Integer.parseInt(request
				.getParameter("enable2FactorAuthenticationLogin")));
		masterUser.setSendPasscodeToDeviceId(Integer.parseInt(request
				.getParameter("sendPasscodeToDeviceId")));
		masterUserDao.modifyMasterUser(masterUser, masterUserId);

	}
}
